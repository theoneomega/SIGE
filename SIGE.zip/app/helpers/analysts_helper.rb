module AnalystsHelper
end
