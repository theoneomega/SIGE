module AreasHelper
end
