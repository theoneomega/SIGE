module FulleventsHelper
end
