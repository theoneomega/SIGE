module IphWeaponsHelper
end
