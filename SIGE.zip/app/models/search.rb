class Search < ActiveRecord::Base
  attr_accessible :colaboraciones, :eventos, :oficios
end
