class Unit < ActiveRecord::Base
  attr_accessible :description, :id
end
