# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Sied::Application.config.secret_token = '0534a9a117f2670218da2e685d367132d11ed9d881e393fbbb8a95e8d5e994b337c01ccc9e921ab2cc1d976044fdf14rtg4c1a6f7e706cc346a5e57978f9cd447a338c848f7'
